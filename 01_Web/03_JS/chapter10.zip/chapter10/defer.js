// h1 태그의 배경 색상 변경
// 태그 선택자라 h1에 아무것도 안 넣어줌.
// document는 위에서 부터 읽어옴
document.querySelector('h1').style.backgroundColor = 'red';

// h1 태그의 글자 색상 변경
document.querySelector('h2').style.color = 'red';
