// 경고창을 출력합니다.
alert('Hello JavaScript..!');
