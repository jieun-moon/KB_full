package ch06.sec06.exam01;

public class Car {
    //필드 선언
    //같은 패키지 내에서만 접근 가능(default 접근 제한자 생략)
    String model; //변수가 가지는 기본값: null
    boolean start; //변수가 가지는 기본값: false
    int speed; //변수가 가지는 기본값: 0
}
