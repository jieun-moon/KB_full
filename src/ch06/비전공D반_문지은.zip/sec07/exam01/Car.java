package ch06.sec07.exam01;

public class Car {
    //생성자 선언
    Car(String model, String color, int maxSpeed){}
}
